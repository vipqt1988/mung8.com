
# Alpha Fetch Site

Site mini (Node + Express) giúp lấy thống kê điểm Alpha Binance cho **nhiều** ví cùng lúc từ [bn-alpha.site](https://www.bn-alpha.site/).

## Cài đặt

```bash
git clone <repo>
cd alpha-fetch-site
npm install
npm start          # Server chạy tại http://localhost:3000
```

## Sử dụng

1. Mở trình duyệt tới `http://localhost:3000`.
2. Dán danh sách địa chỉ ví (mỗi dòng 1 ví).
3. Nhấn **Fetch** → kết quả hiển thị bảng.

> **Lưu ý:**  
> - `bn-alpha.site` không bật CORS ⇒ mình fetch **server‑side**, hoàn toàn an toàn.  
> - Các selector trong `server.js` (`#points`, `#today-volume`, v.v.) chỉ là _placeholder_.  
>   Bạn mở DevTools, copy ID/class thực tế và chỉnh lại cho khớp UI của site gốc.  
> - Nếu site gốc đổi layout / chặn bot, chuyển sang Puppeteer headless hoặc remote API khác.
