
document.getElementById('btn').addEventListener('click', async () => {
  const textarea = document.getElementById('addresses');
  const rows = textarea.value.split(/\n+/).map(s => s.trim()).filter(Boolean);
  if (!rows.length) {
    alert('Nhập ít nhất 1 địa chỉ ví!');
    return;
  }

  const res = await fetch('/api/fetch', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ addresses: rows })
  });

  const data = await res.json();
  const tbody = document.querySelector('#result tbody');
  tbody.innerHTML = '';
  data.forEach(d => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${d.address}</td>
      <td>${d.points ?? ''}</td>
      <td>${d.todayVolume ?? ''}</td>
      <td>${d.todayTxs ?? ''}</td>
      <td>${d.todayGas ?? ''}</td>
      <td>${d.error ? '<span class="error">' + d.error + '</span>' : 'OK'}</td>
    `;
    tbody.appendChild(tr);
  });
  document.getElementById('result').hidden = false;
});
