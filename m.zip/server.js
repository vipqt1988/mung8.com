
import express from 'express';
import fetch from 'node-fetch';
import cheerio from 'cheerio';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

async function fetchStats(address) {
  const url = `https://www.bn-alpha.site/?address=${address}`;

  const html = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Alpha Stats Crawler)'
    }
  }).then(r => r.text());

  const $ = cheerio.load(html);

  // NOTE: The selectors below are placeholders — open DevTools on bn-alpha.site
  // to confirm the right IDs / classes and adjust accordingly.
  const points = $('#points').text().trim() || null;
  const todayVolume = $('#today-volume').text().trim() || null;
  const todayTxs = $('#today-tx').text().trim() || null;
  const todayGas = $('#today-gas').text().trim() || null;

  return { address, points, todayVolume, todayTxs, todayGas };
}

app.post('/api/fetch', async (req, res) => {
  const { addresses } = req.body;
  if (!Array.isArray(addresses) || !addresses.length) {
    return res.status(400).json({ error: 'addresses must be a non‑empty array' });
  }

  const tasks = addresses.map(a => fetchStats(a.trim()).catch(err => ({ address: a, error: err.message })));
  const results = await Promise.all(tasks);
  res.json(results);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server listening on http://localhost:${PORT}`));
